﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace CybersecurityAwarenessChatbot
{
    // Memory manager to store user details and last conversation context
    public static class MemoryManager
    {
        private static Dictionary<string, string> memory = new Dictionary<string, string>();

        public static void Store(string key, string value)
        {
            memory[key] = value;
        }

        public static string Retrieve(string key)
        {
            return memory.TryGetValue(key, out var value) ? value : null;
        }
    }

    // Delegate for response methods
    public delegate string ResponseDelegate();

    public class Chatbot
    {
        private static readonly Random _random = new Random();

        public static void StartChatbot()
        {
            GreetingResponse();  // Ask for the user's name and store it

            Console.WriteLine("Type 'help' to get started or 'exit' to quit.\n");

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("You:   ");
                Console.ResetColor();

                string userInput = Console.ReadLine()?.Trim().ToLower() ?? string.Empty;

                if (userInput == "exit")
                {
                    Console.WriteLine("Stay safe online! Goodbye.");
                    break;
                }
                else if (userInput == "help")
                {
                    ShowHelp();
                }
                else
                {
                    ResponseHandler.Handle(userInput);
                }
            }
        }

        private static void GreetingResponse()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            string welcomeMessage = "Welcome to PUPFED - Your Cybersecurity Awareness Assistant!";
            Console.WriteLine(welcomeMessage);
            Console.ResetColor();

            Console.Write("Please enter your name: ");
            string userName = Console.ReadLine()?.Trim() ?? string.Empty;

            if (!string.IsNullOrEmpty(userName))
            {
                MemoryManager.Store("userName", userName);
                string personalGreet = $"Hello, {userName}! I'm here to help you learn about cybersecurity.";
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(personalGreet);
                Console.ResetColor();
            }
            else
            {
                string defaultGreet = "It seems you didn't enter a name. No worries, let's continue!";
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(defaultGreet);
                Console.ResetColor();
            }
        }

        private static void ShowHelp()
        {
            Console.WriteLine("\nHere are some topics you can ask about:");
            Console.WriteLine("- How are you");
            Console.WriteLine("- What is cybersecurity?");
            Console.WriteLine("- How do I protect my password?");
            Console.WriteLine("- What is phishing?");
            Console.WriteLine("- How do I update my software?");
            Console.WriteLine("- What is malware?");
            Console.WriteLine("- Tell me a fun fact");
        }
    }

    public static class ResponseHandler
    {
        private static readonly Random _random = new Random();

        // Keyword-to-delegate mapping for responses
        private static readonly Dictionary<string, ResponseDelegate> _responses = new Dictionary<string, ResponseDelegate>(StringComparer.OrdinalIgnoreCase)
        {
            { "password", () => "Password Tip: Use a strong, unique password for each account, at least 12 characters long with a mix of upper, lower, digits, and symbols." },
            { "scam", () => "Scam Warning: Always verify the sender's address and never provide personal info in unsolicited messages." },
            { "privacy", () => {
                    var name = MemoryManager.Retrieve("userName") ?? "there";
                    return $"Great choice, {name}! Privacy is crucial. Always review app permissions and limit data sharing.";
                }
            },
            { "cybersecurity", () => "Cybersecurity refers to protecting systems and data from digital attacks aimed at access, change, or destruction of information." },
            { "two-factor authentication", () => "2FA adds an extra layer by requiring a second verification step like a text code or authenticator app." },
            { "vpn", () => "A VPN encrypts your internet connection, hiding your activity from eavesdroppers on public or private networks." },
            { "malware", () => "Malware is malicious software designed to damage or gain unauthorized access. Keep your antivirus up to date." },
        };

        // Predefined lists for random responses
        private static readonly List<string> _phishingTips = new List<string>
        {
            "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organizations.",
            "Hover over links to see the actual URL before clicking, and never open attachments from unknown senders.",
            "Look for spelling and grammar mistakes—many phishing emails contain them as signs of fraud."
        };

        private static readonly List<string> _funFacts = new List<string>
        {
            "The first computer virus was called 'Brain' and emerged in 1986.",
            "'123456' remains one of the most common passwords, despite known risks.",
            "Cybercrime is estimated to generate over $6 trillion annually worldwide."
        };

        // Mapping for sentiment detection (simple)
        private static readonly Dictionary<string, string> _sentimentResponses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "worried", "It's completely understandable to feel that way. Scammers can be very convincing. Let me share some tips to help you stay safe." },
            { "curious", "Curiosity is great! What would you like to learn more about in cybersecurity?" },
            { "frustrated", "I understand this can be tricky. Let's break it down step by step—what topic is causing frustration?" },
        };

        public static void Handle(string userInput)
        {
            // Sentiment Detection
            foreach (var sentiment in _sentimentResponses)
            {
                if (userInput.Contains(sentiment.Key, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine(sentiment.Value);
                    return;
                }
            }

            // Memory: favorite topic
            if (userInput.StartsWith("i'm interested in ") || userInput.StartsWith("i am interested in "))
            {
                var topic = userInput.Substring(userInput.IndexOf("in ", StringComparison.OrdinalIgnoreCase) + 3);
                MemoryManager.Store("favoriteTopic", topic);
                var name = MemoryManager.Retrieve("userName") ?? "there";
                Console.WriteLine($"Got it, {name}! I'll remember that you're interested in {topic}.");
                return;
            }

            // Random fun fact
            if (userInput.Contains("fun fact"))
            {
                var fact = _funFacts[_random.Next(_funFacts.Count)];
                Console.WriteLine(fact);
                return;
            }

            // Random phishing tips
            if (userInput.Contains("phishing"))
            {
                var tip = _phishingTips[_random.Next(_phishingTips.Count)];
                Console.WriteLine(tip);
                return;
            }

            // Keyword responses
            foreach (var kvp in _responses)
            {
                if (userInput.Contains(kvp.Key, StringComparison.OrdinalIgnoreCase))
                {
                    // Store last keyword for follow-up
                    MemoryManager.Store("lastTopic", kvp.Key);
                    Console.WriteLine(kvp.Value());
                    return;
                }
            }

            // Conversation Flow: if user wants more details
            if (userInput.Contains("more details") || userInput.Contains("confused"))
            {
                var last = MemoryManager.Retrieve("lastTopic");
                if (!string.IsNullOrEmpty(last) && _responses.ContainsKey(last))
                {
                    Console.WriteLine($"Sure, here's more about {last}: {_responses[last]().ToLower()}");
                }
                else
                {
                    Console.WriteLine("Can you specify which topic you'd like more details on?");
                }
                return;
            }

            // Default fallback response
            Console.WriteLine("I'm not sure I understand that. Can you try rephrasing?");
        }
    }
}