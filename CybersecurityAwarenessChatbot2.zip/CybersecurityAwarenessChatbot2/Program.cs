﻿using System;

namespace CybersecurityAwarenessChatbot
{
    class Program
    {
        static void Main()
        {
            // Display the ASCII logo at startup
            ASCIIArt.DisplayLogo();

            // Start the chatbot interaction
            Chatbot.StartChatbot();
        }
    }

    // ASCII art for branding
    public static class ASCIIArt
    {
        public static void DisplayLogo()
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(@"  

            ██████╗ ██╗   ██╗██████╗ ███████╗███████╗██████╗ 
            ██╔══██╗██║   ██║██╔══██╗██╔════╝██╔════╝██╔══██╗
            ██████╔╝██║   ██║██████╔╝█████╗  █████╗  ██║  ██║
            ██╔═══╝ ██║   ██║██╔═══╝ ██╔══╝  ██╔══╝  ██║  ██║
            ██║     ╚██████╔╝██║     ██║     ███████╗██████╔╝
            ╚═╝      ╚═════╝ ╚═╝     ╚═╝     ╚══════╝╚═════╝

             PUP (Potentially Unwanted Programs), Fed (Federal Cybersecurity Concerns)

                           Cybersecurity Awareness Chatbot

            ");
            Console.ResetColor();
        }
    }
}